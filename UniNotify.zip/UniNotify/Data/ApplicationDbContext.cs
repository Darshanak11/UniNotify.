using Microsoft.EntityFrameworkCore;
using UniNotify.Models;
namespace UniNotify.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }

        public DbSet<Faculty> Faculties { get; set; }

        public DbSet<UniNotify.Models.Feedback> Feedbacks { get; set; }

        public DbSet<Attendance> Attendances { get; set; }

        public DbSet<Notification> Notifications { get; set; }

        public DbSet<FacultyAttendance> FacultyAttendances { get; set; }
    }
}
