using Microsoft.AspNetCore.Mvc;
using UniNotify.Data;
using UniNotify.Models;
using System.Linq;
using System.Threading.Tasks;

namespace UniNotify.Controllers
{
    public class NotificationController : Controller
    {
        private readonly ApplicationDbContext _context;

        public NotificationController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var notifications = _context.Notifications.ToList();
            return View(notifications);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Notification notification)
        {
            if (ModelState.IsValid)
            {
                _context.Notifications.Add(notification);
                await _context.SaveChangesAsync();
                
                TempData["Success"] = "sented"; 
                return RedirectToAction("Index");
            }
            return View(notification);
        }
    }
}
