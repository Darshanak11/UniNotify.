using Microsoft.AspNetCore.Mvc;
using UniNotify.Data;
using System.Linq;
namespace UniNotify.Controllers
{
    public class AttendanceController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AttendanceController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult ViewAttendance()
        {
            if (Request.Cookies.TryGetValue("StudentUSN", out var usn))
            {
                var attendance = _context.Attendances.Where(a => a.StudentUSN == usn).ToList();
                return View(attendance);
            }
            return RedirectToAction("Login", "Student");
        }
    }
}
