using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UniNotify.Data;
using UniNotify.Models;

namespace UniNotify.Controllers
{
    public class FeedbackController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;

        public FeedbackController(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            return RedirectToAction("ViewFeedback");
        }

        public IActionResult Create()
        {
            ViewBag.Faculties = _context.Faculties.ToList();
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(UniNotify.Models.Feedback model)
        {
            if (ModelState.IsValid)
            {
                model.TargetFacultyName = "University Director/Administration";

                if (model.TargetFacultyId.HasValue)
                {
                    var faculty = _context.Faculties.Find(model.TargetFacultyId.Value);
                    if (faculty != null)
                    {
                        model.TargetFacultyName = faculty.Name;
                    }
                }

                _context.Feedbacks.Add(model);
                await _context.SaveChangesAsync();

                return RedirectToAction("Dashboard", "Student");
            }

            ViewBag.Faculties = _context.Faculties.ToList();
            return View(model);
        }

        public async Task<IActionResult> ViewFeedback()
        {
            
            if (Request.Cookies.TryGetValue("FacultyId", out var idStr) && int.TryParse(idStr, out int facultyId))
            {
                var teacherFeedbacks = await _context.Feedbacks
                    .Where(f => f.TargetFacultyId == facultyId)
                    .OrderByDescending(f => f.Id)
                    .ToListAsync();
                
                ViewBag.UserType = "Faculty";
                return View(teacherFeedbacks);
            }

            if (Request.Cookies.TryGetValue("IsAdmin", out var isAdmin) && isAdmin == "true")
            {
                var allFeedbacks = await _context.Feedbacks
                    .OrderByDescending(f => f.Id)
                    .ToListAsync();
                
                ViewBag.UserType = "Admin";
                return View(allFeedbacks);
            }

            
            return RedirectToAction("Login", "Faculty");
        }
    }
}
