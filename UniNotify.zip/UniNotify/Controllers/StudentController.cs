using Microsoft.AspNetCore.Mvc;
using UniNotify.Data;
using System.Linq;
using UniNotify.Models;

namespace UniNotify.Controllers
{
    public class StudentController : Controller
    {
        private readonly ApplicationDbContext _context;

        public StudentController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            if (string.IsNullOrWhiteSpace(email) || !email.EndsWith("@student.nitte.edu.in", System.StringComparison.OrdinalIgnoreCase))
            {
                ViewBag.Message = "Only students with email ending in @student.nitte.edu.in can login.";
                return View();
            }

            var student = _context.Students
                .FirstOrDefault(s => s.Email == email && s.Password == password);

            if (student != null)
            {
                
                Response.Cookies.Append("StudentUSN", student.USN, new Microsoft.AspNetCore.Http.CookieOptions { Expires = System.DateTimeOffset.Now.AddDays(1) });
                return RedirectToAction("Dashboard");
            }

            ViewBag.Message = "Invalid Login Credentials";
            return View();
        }

        public IActionResult Dashboard()
        {
            var today = System.DateTime.Today;
            var facultyStatuses = _context.Faculties.Select(f => new FacultyStatusViewModel
            {
                FacultyName = f.Name,
                Subject = f.Subject,
                IsPresent = _context.FacultyAttendances
                    .Where(fa => fa.FacultyId == f.Id && fa.Date.Date == today)
                    .OrderByDescending(fa => fa.Id)
                    .Select(fa => fa.IsPresent)
                    .FirstOrDefault()
            }).ToList();

            ViewBag.FacultyStatuses = facultyStatuses;
            return View();
        }

        
        public IActionResult Register()
        {
            return View();
        }

        
        [HttpPost]
        public IActionResult Register(string Name, string Email, string USN, string Password)
        {
            if (string.IsNullOrWhiteSpace(Name) || string.IsNullOrWhiteSpace(Email) || string.IsNullOrWhiteSpace(USN) || string.IsNullOrWhiteSpace(Password))
            {
                ViewBag.Message = "Please fill all fields.";
                return View();
            }

            if (!Email.EndsWith("@student.nitte.edu.in", System.StringComparison.OrdinalIgnoreCase))
            {
                ViewBag.Message = "Email must end with @student.nitte.edu.in";
                return View();
            }

            
            var exists = _context.Students.Any(s => s.USN == USN || s.Email == Email);
            if (exists)
            {
                ViewBag.Message = "USN or Email already registered.";
                return View();
            }

            var student = new Student
            {
                Name = Name,
                Email = Email,
                USN = USN,
                Password = Password
            };

            _context.Students.Add(student);
            _context.SaveChanges();

        
            return RedirectToAction("Login");
        }

        public IActionResult Logout()
        {
            Response.Cookies.Delete("StudentUSN");
            return RedirectToAction("Login");
        }
    }
}
