using Microsoft.AspNetCore.Mvc;
using UniNotify.Data;
using UniNotify.Models;
using System.Linq;
using System.Threading.Tasks;

namespace UniNotify.Controllers
{
    public class FacultyController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FacultyController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Dashboard()
        {
            if (Request.Cookies.TryGetValue("FacultyId", out var idStr) && int.TryParse(idStr, out int facultyId))
            {
                var today = System.DateTime.Today;
                var latestStatus = _context.FacultyAttendances
                    .Where(fa => fa.FacultyId == facultyId && fa.Date.Date == today)
                    .OrderByDescending(fa => fa.Id)
                    .FirstOrDefault();

                ViewBag.FacultyId = facultyId;
                ViewBag.IsPresentToday = latestStatus?.IsPresent ?? false;
            }
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            if (string.IsNullOrWhiteSpace(email) || !email.EndsWith("@nitte.edu.in", System.StringComparison.OrdinalIgnoreCase))
            {
                ViewBag.Message = "Only faculty with email ending in @nitte.edu.in can login.";
                return View();
            }

            var faculty = _context.Faculties
                .FirstOrDefault(f => f.Email == email && f.Password == password);

            if (faculty != null)
            {
                Response.Cookies.Append("FacultyId", faculty.Id.ToString(), new Microsoft.AspNetCore.Http.CookieOptions { Expires = System.DateTimeOffset.Now.AddDays(1) });
                return RedirectToAction("Dashboard");
            }

            ViewBag.Message = "Invalid Login Credentials";
            return View();
        }

        public IActionResult AddAttendance()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddAttendance(Attendance attendance)
        {
            var existing = _context.Attendances.FirstOrDefault(a => a.StudentUSN == attendance.StudentUSN && a.Subject == attendance.Subject);
            if (existing != null)
            {
                existing.TotalClasses = attendance.TotalClasses;
                existing.AttendedClasses = attendance.AttendedClasses;
                _context.Attendances.Update(existing);
            }
            else
            {
                _context.Attendances.Add(attendance);
            }
            await _context.SaveChangesAsync();

            return RedirectToAction("Dashboard");
        }

       
        public IActionResult Register()
        {
            return View();
        }

        
        [HttpPost]
        public IActionResult Register(string Name, string Email, string Subject, string Password)
        {
            if (string.IsNullOrWhiteSpace(Name) || string.IsNullOrWhiteSpace(Email) || string.IsNullOrWhiteSpace(Subject) || string.IsNullOrWhiteSpace(Password))
            {
                ViewBag.Message = "Please fill all fields.";
                return View();
            }

            if (!Email.EndsWith("@nitte.edu.in", System.StringComparison.OrdinalIgnoreCase))
            {
                ViewBag.Message = "Email must end with @nitte.edu.in";
                return View();
            }

            var exists = _context.Faculties.Any(f => f.Email == Email);
            if (exists)
            {
                ViewBag.Message = "Email already registered.";
                return View();
            }

            var faculty = new Faculty
            {
                Name = Name,
                Email = Email,
                Subject = Subject,
                Password = Password
            };

            _context.Faculties.Add(faculty);
            _context.SaveChanges();

            return RedirectToAction("Login");
        }

        [HttpPost]
        public IActionResult ToggleDailyStatus(int facultyId, bool isPresent)
        {
            var fa = new FacultyAttendance
            {
                FacultyId = facultyId,
                Date = System.DateTime.Today,
                IsPresent = isPresent
            };
            _context.FacultyAttendances.Add(fa);
            _context.SaveChanges();
            
            return RedirectToAction("Dashboard");
        }

        public IActionResult Logout()
        {
            Response.Cookies.Delete("FacultyId");
            return RedirectToAction("Login");
        }
    }
}
