using Microsoft.AspNetCore.Mvc;
using UniNotify.Data;
using UniNotify.Models;
using System.Linq;
using System.Collections.Generic;

namespace UniNotify.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            
            var cleanUsername = username?.Trim().ToLower();
            var cleanPassword = password?.Trim();

            
            if (cleanUsername == "admin" && cleanPassword == "admin@5678")
            {
                Response.Cookies.Append("IsAdmin", "true", new Microsoft.AspNetCore.Http.CookieOptions { Expires = System.DateTimeOffset.Now.AddDays(1) });
                return RedirectToAction("Dashboard");
            }

            ViewBag.Message = "Invalid Admin Credentials";
            return View();
        }

        public IActionResult Dashboard()
        {
            return View();
        }

        public IActionResult Students()
        {
            var students = _context.Students.ToList();
            return View(students);
        }




        [HttpPost]
        public IActionResult DeleteStudent(int id)
        {
            var student = _context.Students.Find(id);
            if (student != null)
            {
                _context.Students.Remove(student);
                _context.SaveChanges();
                TempData["Success"] = "Student removed successfully.";
            }
            return RedirectToAction("Students");
        }

        public IActionResult Faculty()
        {
            return RedirectToAction("Faculties");
        }

        public IActionResult Faculties()
        {
            var faculties = _context.Faculties.ToList() ?? new List<Faculty>();
            return View("Faculties", faculties);
        }



        [HttpPost]
        public IActionResult DeleteFaculty(int id)
        {
            var faculty = _context.Faculties.Find(id);
            if (faculty != null)
            {
                _context.Faculties.Remove(faculty);
                _context.SaveChanges();
                TempData["Success"] = "Faculty member removed successfully.";
            }
            return RedirectToAction("Faculties");
        }



        [HttpPost]
        public IActionResult DeleteNotification(int id)
        {
            var notification = _context.Notifications.Find(id);
            if (notification != null)
            {
                _context.Notifications.Remove(notification);
                _context.SaveChanges();
                TempData["Success"] = "Notification deleted successfully.";
            }
            return RedirectToAction("Index", "Notification");
        }

        [HttpPost]
        public IActionResult DeleteFeedback(int id)
        {
            var feedback = _context.Feedbacks.Find(id);
            if (feedback != null)
            {
                _context.Feedbacks.Remove(feedback);
                _context.SaveChanges();
                TempData["Success"] = "Feedback removed successfully.";
            }
            return RedirectToAction("ViewFeedback", "Feedback");
        }

        public IActionResult DailyAttendance()
        {
            var today = System.DateTime.Today;
            var facultyStatuses = _context.Faculties.Select(f => new FacultyStatusViewModel
            {
                FacultyName = f.Name,
                Subject = f.Subject,
                IsPresent = _context.FacultyAttendances
                    .Where(fa => fa.FacultyId == f.Id && fa.Date.Date == today)
                    .OrderByDescending(fa => fa.Id)
                    .Select(fa => fa.IsPresent)
                    .FirstOrDefault()
            }).ToList();

            return View(facultyStatuses);
        }

        public IActionResult Logout()
        {
            
            return RedirectToAction("Login");
        }
    }
}
