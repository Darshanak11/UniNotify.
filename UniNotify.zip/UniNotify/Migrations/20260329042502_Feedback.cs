using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UniNotify.Migrations
{
    /// <inheritdoc />
    public partial class FeedbackMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "Complaints",
                newName: "Feedbacks");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "Feedbacks",
                newName: "Complaints");
        }
    }
}
