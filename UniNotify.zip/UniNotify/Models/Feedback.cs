using System.ComponentModel.DataAnnotations;

namespace UniNotify.Models
{
    public class Feedback
    {
        public int Id { get; set; }

        [Required]
        public string Subject { get; set; }

        [Required]
        public string Message { get; set; }

        public int? TargetFacultyId { get; set; }
        public string? TargetFacultyName { get; set; }
    }
}
