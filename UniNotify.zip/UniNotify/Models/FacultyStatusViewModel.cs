namespace UniNotify.Models
{
    public class FacultyStatusViewModel
    {
        public string FacultyName { get; set; } = string.Empty;
        public string Subject { get; set; } = string.Empty;
        public bool IsPresent { get; set; }
    }
}
