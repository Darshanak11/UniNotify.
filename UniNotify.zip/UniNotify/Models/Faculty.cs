﻿namespace UniNotify.Models
{
    public class Faculty
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string Subject { get; set; } = string.Empty;

        public string Password { get; set; } = string.Empty;
    }
}
