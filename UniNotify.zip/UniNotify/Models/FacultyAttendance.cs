using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace UniNotify.Models
{
    public class FacultyAttendance
    {
        public int Id { get; set; }
        
        public int FacultyId { get; set; }
        
        [ForeignKey("FacultyId")]
        public Faculty? Faculty { get; set; }

        public DateTime Date { get; set; }

        public bool IsPresent { get; set; }
    }
}
