﻿namespace UniNotify.Models
{
    public class Attendance
    {
        public int Id { get; set; }

        public required string StudentUSN { get; set; }

        public required string Subject { get; set; }

        public int TotalClasses { get; set; }

        public int AttendedClasses { get; set; }
    }
}
