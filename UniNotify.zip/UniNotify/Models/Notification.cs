﻿namespace UniNotify.Models
{
    public class Notification
    {
        public int Id { get; set; }

        public required string Message { get; set; }

        public required string FacultyName { get; set; }

        public DateTime Date { get; set; }
    }
}
